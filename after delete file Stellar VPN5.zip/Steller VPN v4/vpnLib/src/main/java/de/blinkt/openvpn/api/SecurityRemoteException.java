/*
 * Copyright (c) 2012-2016 Arne Schwabe
 * Distributed under the GNU GPL v2 with additional terms. For full terms see the file doc/LICENSE.txt
 */

package de.blinkt.openvpn.api;

import android.os.RemoteException;

public class SecurityRemoteException extends RemoteException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
