package com.stellar.vpn;

import static com.stellar.vpn.utils.NotificationUtils.sendNotification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.util.Log;
import android.widget.Toast;

import com.stellar.vpn.model.Server;
import com.stellar.vpn.utils.CheckInternetConnection;
import com.stellar.vpn.utils.Pref;

import de.blinkt.openvpn.OpenVpnApi;


public class OnBootReceiver extends BroadcastReceiver {
    CheckInternetConnection connection;
    Server server;
    Pref pref;
    boolean internetConnected;
    boolean autoConnectEnabled;
//    @Override
//    public void onReceive(Context context, Intent intent) {
//        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
//            Log.d("Boot Completeed", "Boot Completed");
//            pref = new Pref(context);
//            server = pref.getServer();
//
//            connection = new CheckInternetConnection();
//            internetConnected = connection.netCheck(context);
//            autoConnectEnabled = pref.getAutoConnect();
//
//            if (autoConnectEnabled) {
//                if (internetConnected) {
//                    // Checking permission for network monitor
//                    Intent mIntent = VpnService.prepare(context);
//
//                    if (intent != null) {
//                        // TODO: Request VPN permission/ network monitor permission
//                    } else //have already permission
//                    {
//                        try {
//                            Log.i("VPN Boot", "Trying to connect vpn on boot");
//
//                            OpenVpnApi.startVpn(context, server.getOvpn(), server.getCountry(), server.getOvpnUserName(), server.getOvpnUserPassword());
//
//                        } catch (Exception e) {
//                            Log.e("VPN Boot", "Error Connecting VPN");
//                        }
//                }
//
//                } else {
//                    sendNotification(context, "No Internet Connection");
//                }
//                Toast.makeText(context, "Boot Completed", Toast.LENGTH_LONG).show();
//                Intent mIntent = new Intent(context, MainActivity.class);
//                mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                context.startActivity(mIntent);
//
//            }
//        }
//    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.d("Boot Completed", "Boot Completed");
            pref = new Pref(context);
            server = pref.getServer();

            connection = new CheckInternetConnection();
            internetConnected = connection.netCheck(context);
            autoConnectEnabled = pref.getAutoConnect();


            if (autoConnectEnabled) {
                if (internetConnected) {
                    // Check if VPN permission is required
                    Intent vpnIntent = VpnService.prepare(context);

                    if (vpnIntent != null) {
                        // VPN permission is required, start the activity to request permission
                        vpnIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(vpnIntent);
                    } else { // Permission is already granted
                        try {
                            Log.i("VPN Boot", "Trying to connect vpn on boot");
                            OpenVpnApi.startVpn(context, server.getOvpn(), server.getCountry(), server.getOvpnUserName(), server.getOvpnUserPassword());
                            //Save the vpn start time
                            pref.saveVpnStartTime();
                        } catch (Exception e) {
                            Log.e("VPN Boot", "Error Connecting VPN", e);
                        }
                    }
                } else {
                    sendNotification(context, "No Internet Connection");
                }
                // You might want to show this Toast only when not attempting to connect to VPN.
                Toast.makeText(context, "Boot Completed", Toast.LENGTH_LONG).show();
            }

            // Starting main activity should probably be outside of the autoConnectEnabled check
            // So it always starts regardless of auto connect preference
            Intent mainIntent = new Intent(context, MainActivity.class);
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(mainIntent);
        }
    }

}


