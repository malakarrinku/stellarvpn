package com.stellar.vpn;

import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class KillSwitch extends AppCompatActivity {
    private static final int REQUEST_VPN_PERMISSION = 0xF1;

    public static void startKillSwitch(Context context){
        Log.i("Kill Switch", "Start Kill Switch");

//        Intent intent = VpnService.prepare(context);
//        if (intent != null) {
//            // The context must be an activity if we're going to use startActivityForResult
//            if(context instanceof Activity) {
//                ((Activity) context).startActivityForResult(intent, REQUEST_VPN_PERMISSION);
//            } else {
//                Log.e("Kill Switch", "Need an Activity context to request VPN permission");
//            }
//        }
        // Check if VPN permission is required
        Intent vpnIntent = VpnService.prepare(context);

        if (vpnIntent != null) {
            // VPN permission is required, start the activity to request permission
            vpnIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(vpnIntent);
        }
        else {
            // Permission is already granted; start the service directly
            Intent vpnStartIntent = new Intent(context, KillSwitchVpnService.class);
            context.startService(vpnStartIntent);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_VPN_PERMISSION && resultCode == RESULT_OK) {
            // The user has granted VPN permission; we can start the service
            startKillSwitch(this);
        } else {
            // Handle the case where the user denied the VPN permission
            Log.e("Kill Switch", "VPN permission was denied by the user.");
        }
    }

    public static void stopKillSwitch(Context context) {
        Log.i("Kill Switch", "Stop Kill Switch");
        Intent intent = new Intent(context, KillSwitchVpnService.class);
        context.stopService(intent);
    }
}
