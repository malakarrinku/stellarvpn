package com.stellar.vpn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.stellar.vpn.api.Const;

import org.json.JSONException;
import org.json.JSONObject;

public class CheckEmailActivity extends AppCompatActivity {

    private LinearLayout email_to_login;
    CardView openemail;
    ImageView backforget;
    private String email;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_email);
        email = getIntent().getStringExtra("email");
        TextView passwordResetText = findViewById(R.id.password_reset_conf_text); // Assuming you have a TextView with the id emailTextView for displaying the email
        passwordResetText.setText("We sent a password reset link to " + email);

        email_to_login=findViewById(R.id.email_to_login);
        openemail=findViewById(R.id.openemail);
        backforget=findViewById(R.id.backforget);

        TextView resendEmailTextView = findViewById(R.id.resendEmailTextView); // Assuming you have a TextView with the id resendEmailTextView for "Click to resend"
        resendEmailTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performResetPassword(email);
            }
        });

        backforget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(CheckEmailActivity.this,ForgotPasswordActivity.class);
                startActivity(intent);
                finish();
            }
        });;

        email_to_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(CheckEmailActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        openemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mailClient = new Intent(Intent.ACTION_VIEW);
                mailClient.setClassName("com.google.android.gm", "com.google.android.gm.ConversationListActivity");

                try {
                    startActivity(mailClient);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(CheckEmailActivity.this, "Gmail app not found", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    private void performResetPassword(String email) {

        String url = Const.reset_pass_api + "?username=" + email;

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sending Email...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            int responseCode = jsonResponse.getInt("response_code");

                            if (responseCode == 200) {
                                Toast.makeText(CheckEmailActivity.this, "Email sent", Toast.LENGTH_SHORT).show();


                            } else {
                                Toast.makeText(CheckEmailActivity.this, "User Does not Exist", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(CheckEmailActivity.this, "Error parsing response: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(CheckEmailActivity.this, "Error occurred: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        return;
    }
}