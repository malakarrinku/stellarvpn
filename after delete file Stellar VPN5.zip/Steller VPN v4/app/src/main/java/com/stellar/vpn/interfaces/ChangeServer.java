package com.stellar.vpn.interfaces;

import com.stellar.vpn.model.Server;


/***
 * Created By Saurya (ChikuAI Official)
 * Our Website = https://developer.chikuaicode.com/
 * Date : Fri,August,05 / 09 / 2022
 * Updated : Fri,September,23 /09 /2022
 */

public interface ChangeServer {
    void newServer(Server server);
}
