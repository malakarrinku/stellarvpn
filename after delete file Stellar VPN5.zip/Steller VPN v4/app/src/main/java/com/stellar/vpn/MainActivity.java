package com.stellar.vpn;

import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.MutableLiveData;


import com.stellar.vpn.api.Const;

import com.stellar.vpn.fragments.MainFragment;
import com.stellar.vpn.model.Server;

import com.stellar.vpn.utils.Pref;
import com.stellar.vpn.utils.Utils;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.Task;




public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    public static final String TAG = "Z-VPNLITE";
    private static final int REQUEST_CODE = 101;


    public MutableLiveData<Server> defaultServer = new MutableLiveData<>();
    private Fragment fragment;
    private DrawerLayout drawer;
    private Pref preference;
    private boolean activateServer;

    //update
    private static final int UPDATE_REQUEST_CODE = 22;
    AppUpdateManager appUpdateManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_drawer);


        preference = new Pref(this);
        defaultServer.setValue(preference.getServer());

        initializeAll();

        openScreen(fragment, false);

        inAppUpdate();




    }



    private void initializeAll() {
        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        fragment = new MainFragment();
    }
    public void openCloseDrawer() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START, true);
        } else {
            drawer.openDrawer(GravityCompat.START, true);
        }
    }


    void openScreen(Fragment fragmentClass, boolean addToBackStack) {
        FragmentManager manager = getSupportFragmentManager();
        try {
            FragmentTransaction transaction = manager.beginTransaction();
            if (addToBackStack) transaction.addToBackStack(fragmentClass.getTag());
            transaction.replace(R.id.container, fragmentClass);
            transaction.commitAllowingStateLoss();
            manager.executePendingTransactions();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onStop() {
        if (defaultServer.getValue() != null) {
            preference.saveServer(defaultServer.getValue());
        }
        super.onStop();
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {

            case R.id.SBsetting:
                startActivity(new Intent(MainActivity.this, SettingActivity.class));
                break;

            case R.id.SBProfile:
                startActivity(new Intent(MainActivity.this, MyaccountActivity.class));
                break;




            case R.id.nav_server:
                startActivity(new Intent(MainActivity.this, ServersActivity.class));
                break;

            case R.id.nav_share:

                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(Intent.EXTRA_TEXT, "Hey buddy! Download *" + getString(R.string.app_name) + "* \n\nDeveloper Website https:developer.chikuaicode.com :\n\nApp Link https://play.google.com/store/apps/details?id=" + getPackageName());
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                startActivity(Intent.createChooser(sharingIntent, "Share ChikuAI Learning App"));

                break;

            case R.id.nav_rate:
                final String appPackageName = getPackageName();
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                } catch (android.content.ActivityNotFoundException anfe) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                }
                break;


            case R.id.nav_policy:

                Utils.openLink(Const.policy, MainActivity.this);
                break;

        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE && data != null) {
                activateServer = true;
                Server server = data.getParcelableExtra("server");
                defaultServer.postValue(server);
            }
        }
        if (requestCode == UPDATE_REQUEST_CODE) {
            if (resultCode != RESULT_OK) {

                Log.d("updateResult", "onActivityResult: " + resultCode);
                // If the update is cancelled or fails,
                // you can request to start the update again.
            }
        }

    }

    public boolean isActivateServer() {
        return activateServer;
    }
    //update

    private void inAppUpdate() {
        appUpdateManager = AppUpdateManagerFactory.create(this);
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();

        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {

            Log.e("AVAILABLE_VERSION_CODE", appUpdateInfo.availableVersionCode() + "");

            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {

                try {
                    appUpdateManager.startUpdateFlowForResult(
                            // Pass the intent that is returned by 'getAppUpdateInfo()'.
                            appUpdateInfo, AppUpdateType.FLEXIBLE, MainActivity.this, UPDATE_REQUEST_CODE);
                } catch (IntentSender.SendIntentException ignored) {

                }
            }
        });

        appUpdateManager.registerListener(installStateUpdatedListener);

    }

    InstallStateUpdatedListener installStateUpdatedListener = installState -> {
        if (installState.installStatus() == InstallStatus.DOWNLOADED) {
            popupSnackbarForCompleteUpdate();
        } else Log.e("UPDATE", "Not downloaded yet");
    };

    private void popupSnackbarForCompleteUpdate() {

        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content), "Update almost finished!", Snackbar.LENGTH_INDEFINITE);
        //lambda operation used for below action
        snackbar.setAction("Reload", view -> appUpdateManager.completeUpdate());
        snackbar.setActionTextColor(getResources().getColor(R.color.colorAccent));
        snackbar.show();
    }

    long back_pressed;

    @Override
    public void onBackPressed() {
        if (back_pressed + 1000 > System.currentTimeMillis()){
            super.onBackPressed();
        }
        else{
            Toast.makeText(getBaseContext(),
                            "Press once again to exit!", Toast.LENGTH_SHORT)
                    .show();
        }
        back_pressed = System.currentTimeMillis();
    }
}
