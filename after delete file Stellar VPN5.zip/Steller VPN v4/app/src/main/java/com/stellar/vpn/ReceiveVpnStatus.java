package com.stellar.vpn;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.stellar.vpn.model.Server;
import com.stellar.vpn.utils.CheckInternetConnection;
import com.stellar.vpn.utils.Pref;


public class ReceiveVpnStatus extends BroadcastReceiver {
    CheckInternetConnection connection;
    Server server;
    Pref pref;
    boolean internetConnected;
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("BroadcastReceiver2", "onReceive Called");
        try {
//            setStatus(intent.getStringExtra("state"));
            Log.i("Broadcast Receiver 2", intent.getStringExtra("state"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}


