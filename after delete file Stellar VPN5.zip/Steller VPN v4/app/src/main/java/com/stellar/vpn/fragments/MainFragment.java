package com.stellar.vpn.fragments;

import static android.app.Activity.RESULT_OK;

import static com.stellar.vpn.KillSwitch.startKillSwitch;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PorterDuff;
import android.net.VpnService;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Chronometer;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.facebook.ads.NativeAdLayout;
import com.stellar.vpn.MainActivity;
import com.stellar.vpn.ProConfig;
import com.stellar.vpn.R;
import com.stellar.vpn.ServersActivity;


import com.stellar.vpn.api.Const;
import com.stellar.vpn.databinding.FragmentMainBinding;
import com.stellar.vpn.interfaces.ChangeServer;
import com.stellar.vpn.model.Server;

import com.stellar.vpn.utils.CheckInternetConnection;
import com.stellar.vpn.utils.Pref;
import com.stellar.vpn.utils.RuntimePermissionUtils;
import com.stellar.vpn.utils.Utils;

import java.util.Locale;

import de.blinkt.openvpn.OpenVpnApi;
import de.blinkt.openvpn.core.OpenVPNService;
import de.blinkt.openvpn.core.OpenVPNThread;
import de.blinkt.openvpn.core.VpnStatus;



public class MainFragment extends Fragment implements ChangeServer {


    Server server;
    CheckInternetConnection connection;
    OpenVPNThread vpnThread = new OpenVPNThread();
    OpenVPNService vpnService = new OpenVPNService();
    boolean vpnStart = false;
    FragmentMainBinding binding;
    View mView;
    static final int REQUEST_CODE = 101;

    private Chronometer chronometer;

    Pref mPref;
    boolean userRequestedDisconnect = false;



    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        if (mView == null) {

            binding = DataBindingUtil.inflate(inflater, R.layout.fragment_main, container, false);
            mView = binding.getRoot();

            chronometer = mView.findViewById(R.id.durationChronometer);

            mPref = new Pref(mView.getContext());


            initializeAll();


            if (ProConfig.isPremium(mView.getContext())) {
                binding.purchaseLayout.setVisibility(View.VISIBLE);
                binding.purchaseLayout.setOnClickListener(view -> {
                    Intent intent = new Intent(getActivity(), ServersActivity.class);
                    startActivity(intent);
                });
            } else {
                binding.purchaseLayout.setVisibility(View.GONE);
            }

            binding.category.setOnClickListener(view -> {
                if (getActivity() != null) ((MainActivity) getActivity()).openCloseDrawer();
            });


        } else {
            if (mView.getParent() != null) {
                ((ViewGroup) mView.getParent()).removeView(mView);
            }
        }


        loadNative();


        return mView;
    }

    private void loadNative() {

        //        ==================== Native Ads here............



    }


    private void initializeAll() {

//        checkNotificationPermission(getActivity());
        RuntimePermissionUtils.requestNotificationPermission(getActivity());

        ((MainActivity) getActivity()).defaultServer.observe(getActivity(), currentServer -> {

            server = currentServer;
            if (vpnStart) {
                setStatus("CONNECTED");
            } else {
                setStatus("DISCONNECTED");
            }

            binding.countryName.setText(server.getCountry());
            updateCurrentVipServerIcon(server.getFlagUrl());

            if (((MainActivity) getActivity()).isActivateServer()) {
                prepareVpn();
            }

        });

        connection = new CheckInternetConnection();
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(broadcastReceiver, new IntentFilter("connectionState"));

        getIP();


    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        RuntimePermissionUtils.handleRequestPermissionsResult(requestCode, permissions, grantResults, getActivity());
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.durationChronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                long time = SystemClock.elapsedRealtime() - chronometer.getBase();
                int h = (int) (time / 3600000);
                int m = (int) (time - h * 3600000) / 60000;
                int s = (int) (time - h * 3600000 - m * 60000) / 1000;
                chronometer.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s));
            }
        });

        binding.btnConnect.setOnClickListener(v -> {

            if (vpnStart) {
                confirmDisconnect();
            } else {
                prepareVpn();
                Utils.startAnim(binding.buttonRotate, mView.getContext());

            }
        });

        binding.currentConnectionLayout.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent mIntent = new Intent(getActivity(), ServersActivity.class);
                getActivity().startActivityForResult(mIntent, REQUEST_CODE);
//                activityResultLauncher.launch(mIntent);
            }
        });

        isServiceRunning();

        VpnStatus.initLogCache(getActivity().getCacheDir());
    }


    public void confirmDisconnect() {
        userRequestedDisconnect = true; // Set the flag when user initiates disconnection

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setMessage(getActivity().getString(R.string.connection_close_confirm));

        builder.setPositiveButton(getActivity().getString(R.string.yes), (dialog, id) -> stopVpn());

        builder.setNegativeButton(getActivity().getString(R.string.no), (dialog, id) -> {
        });

        // Create the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void prepareVpn() {
        Log.i("Prepare VPN", "Inside Prepare VPN Method");
        if (!vpnStart) {
            binding.taptoconnect.setVisibility(View.GONE);
            if (getInternetStatus()) {
                // Checking permission for network monitor
                Intent intent = VpnService.prepare(getContext());

                if (intent != null) {
                    startActivityForResult(intent, 1);
                } else startVpn();//have already permission

                // Update confection status
                setStatus("connecting");

            } else {
                // No internet connection available
                showToast("you have no internet connection !!");
            }

        } else if (stopVpn()) {
            // VPN is stopped, show a Toast message.
            showToast("Disconnect Successfully");
            prepareVpn();
        }
    }


    public boolean stopVpn() {
        userRequestedDisconnect = true; // Set the flag when user initiates disconnection
        try {
            vpnThread.stop();
            setStatus("connect");
            binding.loca.setVisibility(View.VISIBLE);
            binding.taptoconnect.setVisibility(View.VISIBLE);
            vpnStart = false;
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.i("activity result", "Inside on activity result");
        if (resultCode == RESULT_OK) {
            Log.d("Server Change", "Got selected server");
            if (vpnStart){
                prepareVpn();
            }
            prepareVpn();
        } else {
            showToast("Permission Deny !! ");
        }
    }

    private final ActivityResultLauncher<Intent> activityResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            Log.d("Server Change", "Got selected server");
                            if (vpnStart){
                                prepareVpn();
                            }
                            startVpn();
                        } else {
                            showToast("Permission Deny !! ");
                        }
                    }
            );


    public boolean getInternetStatus() {
        return connection.netCheck(getActivity());
    }


    public void isServiceRunning() {
        setStatus(vpnService.getStatus());
    }


    private void startVpn() {
        userRequestedDisconnect = true;

        Log.d("Start VPN", "Inside start vpn method");
        if (vpnStart){
            stopVpn();
        }
        try {
            OpenVpnApi.startVpn(getContext(), server.getOvpn(), server.getCountry(), server.getOvpnUserName(), server.getOvpnUserPassword());
            binding.logTv.setText("Connecting...");
            binding.logTv.setVisibility(View.VISIBLE);
            vpnStart = true;

            buttonAnim("l");


        } catch (RemoteException e) {
            showToast("Error Connecting VPN");
            Log.e("Error","Error Connecting VPN");
            e.printStackTrace();
        }
    }


    public void setStatus(String connectionState) {

        if (connectionState != null) {

            try {
                binding.ipTv.setText("Waiting for New IP..");
            } catch (Exception e) {
            }

            switch (connectionState) {

                case "DISCONNECTED":
                    vpnStart = false;
                    vpnService.setDefaultStatus();
                    binding.logTv.setText("");
                    binding.connimg.setVisibility(View.GONE);
                    binding.taptoconnect.setVisibility(View.GONE);
                    binding.loca.setVisibility(View.VISIBLE);
                    binding.category.setVisibility(View.VISIBLE);
                    buttonAnim("s");

                    // Stop and reset the chronometer when disconnected
                    chronometer.stop();
                    chronometer.setBase(SystemClock.elapsedRealtime());

                    //Reset the saved time
                    mPref.resetVpnStartTime();

                    try {
                        getIP();
                    } catch (Exception e) {
                    }

                    break;

                case "CONNECTED":
                    vpnStart = true;
                    binding.logTv.setText("Connected");
                    binding.ipTv.setVisibility(View.VISIBLE);
                    binding.ipTv1.setVisibility(View.GONE);
                    binding.connimg.setVisibility(View.VISIBLE);
                    binding.loca.setVisibility(View.VISIBLE);
                    binding.taptoconnect.setVisibility(View.GONE);

                    long connectionStartTime = mPref.getVpnStartTime();
                    Log.d("VPN Start time", "t: "+ connectionStartTime);

                // If the connection start time is available, compute the base time for the chronometer
                    if (connectionStartTime != 0) {
                        chronometer.setBase(connectionStartTime);
                    }
                    else {
                        // Start the chronometer when connected
                        chronometer.setBase(SystemClock.elapsedRealtime());
                        mPref.saveVpnStartTime();
                    }

                    chronometer.start();


                    buttonAnim("c");

                    getIP();

                    break;

                case "WAIT":
                    binding.logTv.setText("waiting for server!!");
                    buttonAnim("l");

                    break;

                case "AUTH":
                    binding.logTv.setText("Please Wait.. !");
                    buttonAnim("l");

                    break;
                case "AUTH_FAILED":
                    Log.i("Auth Failed", "Error connecting vpn");
                    showToast("Error with VPN connection");
                    break;

                case "RECONNECTING":
                    binding.logTv.setText("Reconnecting...");
                    buttonAnim("l");

                    break;

                case "NONETWORK":
                    binding.logTv.setText("No network connection");
                    buttonAnim("l");

                    break;

            }

        }
    }

    private void getIP() {
        StringRequest request = new StringRequest(Const.ip, response -> {

            try {
                String ip = "IP : "+response;
                binding.ipTv.setText(ip);
            } catch (Exception e) {

            }
        }, error -> {

        });
        RequestQueue queue = Volley.newRequestQueue(mView.getContext());
        queue.add(request);

    }


    BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String state = intent.getStringExtra("state");
            if ("DISCONNECTED".equals(state) && !userRequestedDisconnect) {
                // Only activate kill switch if disconnect was not requested by the user
                // Start the kill switch
                boolean killSwitchEnabled = mPref.getSwitchBlock();
                if (killSwitchEnabled) {
                    startKillSwitch(context);
                }
            }
            else if ("AUTH_FAILED".equals(state)){
                userRequestedDisconnect = true;
            }

            else if ("DISCONNECTED".equals(state)) {
                userRequestedDisconnect = false; // Clear the flag on normal disconnection
            }
            try {
                setStatus(intent.getStringExtra("state"));
                Log.i("Broadcast Received", intent.getStringExtra("state"));
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {

                String duration = intent.getStringExtra("duration");
                String lastPacketReceive = intent.getStringExtra("lastPacketReceive");
                String byteIn = intent.getStringExtra("byteIn");
                String byteOut = intent.getStringExtra("byteOut");

                if (duration == null) duration = "00:00:00";
                if (lastPacketReceive == null) lastPacketReceive = "0";
                if (byteIn == null) byteIn = " ";
                if (byteOut == null) byteOut = " ";
                updateConnectionStatus(duration, byteIn, byteOut);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    };


    public void updateConnectionStatus(String duration, String byteIn, String byteOut) {
        binding.durationTv.setText("" + duration);
        String byteinKb = byteIn.split("-")[0];
        String byteoutKb = byteOut.split("-")[0];
        binding.byteInTv.setText(byteinKb);
        binding.byteOutTv.setText(byteoutKb);
    }


    public void showToast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }


    public void updateCurrentVipServerIcon(String serverIcon) {
        Glide.with(getActivity()).load(serverIcon).into(binding.selectedServerIcon);
    }


    @Override
    public void newServer(Server server) {
        this.server = server;
        if (vpnStart) {
            stopVpn();
        }
        prepareVpn();
    }

    //    =======Status======
    private void buttonAnim(String anim) {
        if (anim.contains("c")) {

            binding.vpnBtn.setColorFilter(ContextCompat.getColor(getActivity(), R.color.color_connect), PorterDuff.Mode.CLEAR);
            Utils.startAnim(binding.buttonRotate, mView.getContext());
            binding.btnConnect.setBackgroundResource(R.drawable.swith1);

        } else if (anim.contains("l")) {

            binding.vpnBtn.setColorFilter(ContextCompat.getColor(getActivity(), R.color.color_connecting), android.graphics.PorterDuff.Mode.CLEAR);
            Utils.startAnim(binding.buttonRotate, mView.getContext());
            binding.btnConnect.setBackgroundResource(R.drawable.swith);
        } else {
            binding.vpnBtn.setColorFilter(ContextCompat.getColor(getActivity(), R.color.color_disconnect), android.graphics.PorterDuff.Mode.CLEAR);
            binding.buttonRotate.clearAnimation();
            binding.btnConnect.setBackgroundResource(R.drawable.swith);
        }

    }

}
