package com.stellar.vpn;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;





public class ProConfig {


    public static final String all_month_id = "";
    public static final String all_threemonths_id = "";
    public static final String all_sixmonths_id = "";
    public static final String all_yearly_id = "";


    public static boolean vip_subscription = false;
    public static boolean all_subscription = false;


    public static void setPremium(boolean b, Context context) {
        SharedPreferences.Editor editor = context.getSharedPreferences("premium", MODE_PRIVATE).edit();
        editor.putBoolean("premium", b);
        editor.apply();
    }

    public static boolean isPremium(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("premium", MODE_PRIVATE);
        return prefs.getBoolean("premium", false);
    }

}
