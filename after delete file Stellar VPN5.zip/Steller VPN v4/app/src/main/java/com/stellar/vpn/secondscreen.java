package com.stellar.vpn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

public class secondscreen extends AppCompatActivity {
   private CardView agree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondscreen);
        agree=findViewById(R.id.agree);
//        agree.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(secondscreen.this,LoginActivity.class);
//                startActivity(intent);
//                finish();
//            }
//        });

        agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save to SharedPreferences
                SharedPreferences sharedPref = getSharedPreferences("appPreferences", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean("tos_agreed", true);
                editor.apply();

                // Start the Intent
                Intent intent = new Intent(secondscreen.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
    @Override
    public void onBackPressed() {
        return;
    }
}