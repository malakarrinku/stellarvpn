package com.stellar.vpn.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.stellar.vpn.R;
import com.stellar.vpn.model.Server;
import com.stellar.vpn.utils.Pref;

import java.util.ArrayList;
import java.util.List;

import de.blinkt.openvpn.core.VpnStatus;


/***
 * Created By Saurya (ChikuAI Official)
 * Our Website = https://developer.chikuaicode.com/
 * Date : Fri,August,05 / 09 / 2022
 * Updated : Fri,September,23 /09 /2022
 */

public class FreeServerAdapter extends RecyclerView.Adapter<FreeServerAdapter.MyViewHolder> {

    private ArrayList<Server> serverLists;
    private Context mContext;
    private OnSelectListener selectListener;
    private int AD_TYPE = 0;
    private int CONTENT_TYPE = 1;

    private int selectedPosition = -1;

    public FreeServerAdapter(Context context) {
        this.mContext = context;
        serverLists = new ArrayList<>();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_server, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        if (getItemViewType(position) == CONTENT_TYPE) {
            holder.serverCountry.setText(serverLists.get(position).getCountry());
            Glide.with(mContext)
                    .load(serverLists.get(position).getFlagUrl())
                    .into(holder.serverIcon);

            // Check if the current position is the selected position
            selectedPosition = new Pref(mContext).getServerPosition();
            Log.d("Server Position - v)", "pos: " + selectedPosition);
            if (VpnStatus.isVPNActive()) {
                holder.radio.setChecked(position == selectedPosition);
            }

//            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    selectListener.onSelected(serverLists.get(position));
//                    Log.v("Kabila", serverLists.get(position).getCountry());
//                }
//            });

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    notifyItemChanged(selectedPosition);
                    selectedPosition = holder.getAdapterPosition();
                    notifyItemChanged(selectedPosition);
                    Server selectedServer = serverLists.get(position);

                    selectListener.onSelected(selectedServer);

                    Log.v("Kabila", selectedServer.getCountry());
                }
            });

            holder.radio.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    holder.itemView.performClick(); // Delegate to the item click handler
                }
            });

        } else {

        }

    }

    @Override
    public int getItemCount() {
        return serverLists.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView serverIcon;
        TextView serverCountry;

        RadioButton radio;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            serverIcon = itemView.findViewById(R.id.flag);
            serverCountry = itemView.findViewById(R.id.countryName);
            radio = itemView.findViewById(R.id.radio);
        }
    }

    public void setData(List<Server> servers) {
        serverLists.clear();
        serverLists.addAll(servers);
        notifyDataSetChanged();
    }

    public interface OnSelectListener {
        void onSelected(Server server);
    }

    public void setOnSelectListener(OnSelectListener selectListener) {
        this.selectListener = selectListener;
    }

    @Override
    public int getItemViewType(int position) {
        return serverLists.get(position) == null ? AD_TYPE : CONTENT_TYPE;
    }

    // Add a method to set the selected position from outside, if needed
    public void setSelectedPosition(int position) {
        selectedPosition = position;
        notifyDataSetChanged();
    }

    // Add a method to get the selected position, if needed
    public int getSelectedPosition() {
        return selectedPosition;
    }

    public interface ServerSelected {
        void onServerSelected(Server server);
    }
}
