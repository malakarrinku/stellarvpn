package com.stellar.vpn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.stellar.vpn.utils.Pref;

public class MyaccountActivity extends AppCompatActivity {
    TextView emailTextView;
    Pref pref;
    CardView logout, delete;
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myaccount);

        emailTextView = findViewById(R.id.myaccount_email);
        logout = findViewById(R.id.logoutBtn);
        delete = findViewById(R.id.deleteBtn);
        back = findViewById(R.id.myaccount_back_button);


        pref = new Pref(MyaccountActivity.this);
        String[] credentials = pref.getCredentials();
        String email = credentials[0];

        emailTextView.setText(email);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pref.deleteCredentials();
                Intent intent = new Intent(MyaccountActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pref.deleteCredentials();
                //TODO: Call delete account api
                Intent intent = new Intent(MyaccountActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}