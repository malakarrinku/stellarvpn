package com.stellar.vpn.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;


/***
 * Created By Saurya (ChikuAI Official)
 * Our Website = https://developer.chikuaicode.com/
 * Date : Fri,August,05 / 09 / 2022
 * Updated : Fri,September,23 /09 /2022
 */


public class CheckInternetConnection {

    public boolean netCheck(Context context){
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo nInfo = cm.getActiveNetworkInfo();
        boolean isConnected = nInfo != null && nInfo.isConnectedOrConnecting();
        return isConnected;
    }

}
