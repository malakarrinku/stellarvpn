package com.stellar.vpn.fragments;

import static com.stellar.vpn.utils.Utils.getImgURL;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;


import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.stellar.vpn.MainActivity;
import com.stellar.vpn.R;
import com.stellar.vpn.adapter.FreeServerAdapter;
import com.stellar.vpn.api.Const;
import com.stellar.vpn.model.Server;
import com.stellar.vpn.utils.Pref;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


/***
 * Created By Saurya (ChikuAI Official)
 * Our Website = https://developer.chikuaicode.com/
 * Date : Fri,August,05 / 09 / 2022
 * Updated : Fri,September,23 /09 /2022
 */

public class FreeServersFragment extends Fragment implements FreeServerAdapter.OnSelectListener {


    RecyclerView recyclerView;
    private FreeServerAdapter serverAdapter;
    View layout;

    private List<Server> originalServers;
    private SearchView searchView;

    private com.airbnb.lottie.LottieAnimationView loadingAnimationView;

    private boolean hardCodedPassword = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.fragment_free_server, container, false);


        setHasOptionsMenu(true); // Enable options menu

        recyclerView = layout.findViewById(R.id.recycler_free);
        serverAdapter = new FreeServerAdapter(getActivity());
        serverAdapter.setOnSelectListener(this);
        recyclerView.setAdapter(serverAdapter);
        loadingAnimationView = layout.findViewById(R.id.loadingAnimationView);

        ImageView back_main = layout.findViewById(R.id.back_main);
        back_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
            }
        });

        // Create the SearchView directly in the layout
        searchView = layout.findViewById(R.id.searchView);
        setupSearchView();

        loadServers();

        return layout;
    }

    private void setupSearchView() {
        if (searchView != null) {
            searchView.setQueryHint(getString(R.string.search));

            //Set icon
            // Get the search icon inside the SearchView
            ImageView searchIcon = searchView.findViewById(androidx.appcompat.R.id.search_mag_icon);
            ViewGroup linearLayoutSearchView = (ViewGroup) searchIcon.getParent();

            // Remove the search icon from the current position
            linearLayoutSearchView.removeView(searchIcon);

            // Add it to the end of the layout (right side)
            linearLayoutSearchView.addView(searchIcon);

            // Optional: Adjust the layout margins or padding if needed
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) searchIcon.getLayoutParams();
            params.leftMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics());
            params.rightMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics());
            searchIcon.setLayoutParams(params);

            //Set icon ends here

            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    filterList(newText);
                    return true;
                }
            });
        }
    }



    private void loadServers() {
        // Before sending the request, show the loading animation:
        loadingAnimationView.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);


        // Get the passwords array
        String[] passwords = getResources().getStringArray(R.array.passwords);

        StringRequest request = new StringRequest(Const.api + "?pkg=" + getActivity().getPackageName(), response -> {
            if (!isAdded()) return; // If user back pressed do not try do not attach the list, (crash fix)

            // After loading the servers or in case of an error, hide the animation:
            loadingAnimationView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);

            originalServers = new ArrayList<>(); // Initialize the original servers list
            ArrayList<Server> servers = new ArrayList<>();
            try {
                JSONArray jsonArray = new JSONArray(response);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject object = jsonArray.getJSONObject(i);

                    String countryName = object.getString("alpha-2");
//                    int flagResId = getResources().getIdentifier("flag_" + countryName.toLowerCase(), "drawable", getActivity().getPackageName());

//                    String flagURL = getImgURL(flagResId); // "flag_" + countryName.toLowerCase(); // Assuming drawable names are in the format "flag_us", "flag_uk", etc.

                    // New flag urls

                    String flagName = "flag_" + countryName.toLowerCase().replace("-", "_");

                    int flagResId = getResources().getIdentifier(flagName, "raw", getActivity().getPackageName());

                    String flagURL = getImgURL(flagResId);



//                    int flagResId = getResources().getIdentifier("flags/png/" + countryName.toUpperCase(), "drawable", getActivity().getPackageName());
//
//                    String flagURL = getImgURL(flagResId);
                    // Convert the country name to uppercase as the filenames are in uppercase
//                    String flagName = countryName.toUpperCase();
//
////                  Create the path for the flag asset
//                    String flagURL = "file:///android_asset/flags/" + flagName + ".png";


                    // Extracting the certificate
                    JSONArray certArray = object.getJSONArray("certificate");
                    StringBuilder certBuilder = new StringBuilder();
                    for (int j = 0; j < certArray.length(); j++) {
                        String currentLine = certArray.getString(j);
                        if (!currentLine.startsWith("data-ciphers")) {
                            certBuilder.append(currentLine).append(""); // Adding a newline after each line
                        }
                    }
                    String configString = certBuilder.toString();

                    JSONObject authObject = object.getJSONObject("auth");
                    String username = authObject.getString("username");
                    String password = authObject.getString("password");
//                    password = "215586270"; // Hardcoded password
                    if (hardCodedPassword){
                        int l = passwords.length - 1;
                        if (l >= i) {
                            password = passwords[i];
                        }
                        else {
                            password = passwords[l];
                        }

                    }
                    Log.d("SERVER", "Server:" + countryName+ " Username: "+ username + " Password: "+ password);

                    servers.add(new Server(countryName, flagURL, configString, username, password));
                    originalServers.add(new Server(countryName, flagURL, configString, username, password));
                }
                serverAdapter.setData(servers); // Assuming you have a serverAdapter that needs the data set
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, error -> {
            Log.e("REQUEST_ERROR", "loadServers: " + error.toString());

            loadingAnimationView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);

            // Handle the error here, perhaps show a message to the user
        });

        RequestQueue queue = Volley.newRequestQueue(getActivity()); // Assuming this method is inside a Fragment
        queue.add(request);
    }

    private String loadAssetContentAsString(String assetName) throws IOException {
        InputStream is = getActivity().getAssets().open(assetName);
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
            sb.append('\n');
        }
        br.close();
        return sb.toString();
    }
    private void filterList(String query) {
        ArrayList<Server> filteredServers = new ArrayList<>();
        if (originalServers != null) {
            for (Server server : originalServers) {
                if (TextUtils.isEmpty(query) || server.getCountry().toLowerCase().contains(query.toLowerCase())) {
                    filteredServers.add(server);
                }
            }
        }
        serverAdapter.setData(filteredServers);
    }

    @Override
    public void onSelected(Server server) {
        if (getActivity() != null) {
            Intent mIntent = new Intent();
            mIntent.putExtra("server", server);
            Pref pref = new Pref(getActivity());
            pref.saveServer(server);

            //Save position
            pref.saveServerPosition(serverAdapter.getSelectedPosition());
            getActivity().setResult(getActivity().RESULT_OK, mIntent);
            getActivity().finish();
        }
    }
}