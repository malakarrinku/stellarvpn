package com.stellar.vpn.api;




public class Const {

    //base Url of your VPN Files
    public static String base = "";

    public static String api = "https://stellaruiandroidvpnappapiprod.azurewebsites.net/api/v1/vpncontroller/servers";
    public static String ip = base + "api/ip.php";
    public static String login_api = "https://stellaruiandroidvpnappapiprod.azurewebsites.net/api/v1/logincontroller/auth";
    public static String signup_api = "https://stellaruiandroidvpnappapiprod.azurewebsites.net/api/v1/logincontroller/create";
    public static String reset_pass_api = "https://stellaruiandroidvpnappapiprod.azurewebsites.net/api/v1/logincontroller/resetpassword";
    public static String policy = base + "";

}
