package com.stellar.vpn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.stellar.vpn.api.Const;

import org.json.JSONException;
import org.json.JSONObject;

public class ForgotPasswordActivity extends AppCompatActivity {

   public LinearLayout forgot_to_login;
   CardView reset;
   ImageView back_signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        forgot_to_login=findViewById(R.id.forgot_to_login);
        reset=findViewById(R.id.reset);
        back_signup=findViewById(R.id.back_signup);
        forgot_to_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ForgotPasswordActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        back_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ForgotPasswordActivity.this,SignupActivity.class);
                startActivity(intent);
                finish();
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent(ForgotPasswordActivity.this,CheckEmailActivity.class);
//                startActivity(intent);
//                finish();
//            }

            @Override
            public void onClick(View v) {
                // Assuming you have the email and password fields initialized and getting their texts
                String email = ((TextInputEditText) findViewById(R.id.reset_email)).getText().toString();

                if (!email.isEmpty()) {
                    performResetPassword(email);
                } else {
                    Toast.makeText(ForgotPasswordActivity.this, "Please fill in the form", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void performResetPassword(String email) {

        String url = Const.reset_pass_api + "?username=" + email;

        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sending Email...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            int responseCode = jsonResponse.getInt("response_code");

                            if (responseCode == 200) {
                                Toast.makeText(ForgotPasswordActivity.this, "Email sent", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(ForgotPasswordActivity.this, CheckEmailActivity.class);
                                intent.putExtra("email", email); // Pass the email to CheckEmailActivity
                                startActivity(intent);
                                finish();

                            } else {
                                Toast.makeText(ForgotPasswordActivity.this, "User Does not Exist", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(ForgotPasswordActivity.this, "Error parsing response: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(ForgotPasswordActivity.this, "Error occurred: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        return;
    }
}