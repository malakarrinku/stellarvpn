package com.stellar.vpn;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.stellar.vpn.adapter.TabAdapter;

import com.stellar.vpn.fragments.FreeServersFragment;
import com.stellar.vpn.utils.Utils;




public class ServersActivity extends AppCompatActivity {


    public static boolean resume;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servers);

        ViewPager viewPager = findViewById(R.id.viewPager);
//        TabLayout tabLayout = findViewById(R.id.tabLayout);
        TabAdapter adapter = new TabAdapter(getSupportFragmentManager());


        adapter.addFragment(new FreeServersFragment(), "Free Servers");
        viewPager.setAdapter(adapter);
//

        Utils.setTools("Servers", ServersActivity.this);



    }
}
