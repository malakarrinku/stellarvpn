package com.stellar.vpn.utils;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

import com.stellar.vpn.R;

public class NotificationUtils {

    private static final String CHANNEL_ID = "Steller VPN";
    private static final String CHANNEL_NAME = "steller vpn notification";

    public static void sendNotification(Context context, String str) {
        if (!checkNotificationPermission(context)) {
            return;
        }

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(channel);
        }

        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(context, CHANNEL_ID)
                    .setContentTitle("Steller VPN")
                    .setContentText(str)
                    .setSmallIcon(R.drawable.ic_notification)
                    .build();
        } else {
            // For devices running Android 7 (Nougat) and below
            notification = new Notification.Builder(context)
                    .setContentTitle("Steller VPN")
                    .setContentText(str)
                    .setSmallIcon(R.drawable.ic_notification)
                    .build();
        }

        notificationManager.notify(1, notification);
    }


    public static boolean checkNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (!notificationManager.areNotificationsEnabled()) {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
                context.startActivity(intent);
                return false;
            }
        }
        return true;
    }
}
