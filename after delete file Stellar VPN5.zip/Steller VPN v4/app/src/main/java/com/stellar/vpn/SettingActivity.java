package com.stellar.vpn;

import static com.stellar.vpn.KillSwitch.stopKillSwitch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ToggleButton;
import android.net.Uri;
import android.widget.Toast;

import com.stellar.vpn.utils.Pref;

public class SettingActivity extends AppCompatActivity {

   ImageView set_rightarrow,set_downarrow;
    LinearLayout laysetting;
    CardView CVfaq1,app_version;
    ImageView back_signuptomain;
    ToggleButton toggle_setting,toggle_faq,toggle_app_version, toggle_auto_connect, toggle_switch_block;

    CardView cv_faq, cv_vpn_settings, cv_app_version;

    boolean autoConnectEnabled;
    boolean switchBlockEnabled;
    Pref pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        toggle_setting =findViewById(R.id.toggle_setting);
        laysetting = findViewById(R.id.laysetting);
        toggle_faq=findViewById(R.id.toggle_faq);
        CVfaq1=findViewById(R.id.CVfaq1);
        toggle_app_version=findViewById(R.id.toggle_app_version);
        app_version=findViewById(R.id.app_version);
        back_signuptomain=findViewById(R.id.back_signuptomain);

        cv_faq = findViewById(R.id.cv_faq);
        cv_app_version = findViewById(R.id.cv_app_version);
        cv_vpn_settings = findViewById(R.id.cv_vpn_settings);
        toggle_auto_connect = findViewById(R.id.auto_connect_toggle);
        toggle_switch_block = findViewById(R.id.switch_block_toggle);

        pref = new Pref(this);
        autoConnectEnabled = pref.getAutoConnect();
        switchBlockEnabled = pref.getSwitchBlock();

        // Get the settings and set them to view
        toggle_auto_connect.setChecked(autoConnectEnabled);
        toggle_switch_block.setChecked(switchBlockEnabled);

        toggle_auto_connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Assuming 'toggle_auto_connect' is a CheckBox or Switch
                boolean state = ((CompoundButton) v).isChecked();
                // Save the checked state
                pref.saveAutoConnect(state);
            }
        });

        toggle_switch_block.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Assuming 'toggle_switch_block' is a CheckBox or Switch
                boolean state = ((CompoundButton) v).isChecked();
                // Save the checked state
                pref.saveSwitchBlock(state);
                // if the state is false/unchecked then call stopKillSwitch(context);
                if (!state) {
                    stopKillSwitch(getBaseContext());
                }
            }
        });


        cv_faq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggle_faq.performClick();  // Simulate a click on the toggle_faq ToggleButton
            }
        });

        cv_app_version.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggle_app_version.performClick();  // Simulate a click on the toggle_app_version ToggleButton
            }
        });

        cv_vpn_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggle_setting.performClick();  // Simulate a click on the toggle_setting ToggleButton
            }
        });


        back_signuptomain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SettingActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

        toggle_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (laysetting.getVisibility() == View.GONE) {
                    // If lay_setting is currently invisible, make it visible
                    laysetting.setVisibility(View.VISIBLE);
                } else {
                    // If lay_setting is currently visible, hide it
                    laysetting.setVisibility(View.GONE);
                }
            }
        });


        toggle_faq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri webpage = Uri.parse("https://stellarsecurity.com/contact-us");
                Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

                toggle_faq.setChecked(true);

                // Check if there is a browser app that can handle the intent
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    // Handle the error or provide feedback to the user
                    Toast.makeText(getApplicationContext(), "No browser found to open the link", Toast.LENGTH_SHORT).show();
                }
            }
        });


//toggle app version
        toggle_app_version.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (app_version.getVisibility() == View.GONE) {
                    // If lay_setting is currently invisible, make it visible
                    app_version.setVisibility(View.VISIBLE);
                } else {
                    // If lay_setting is currently visible, hide it
                    app_version.setVisibility(View.GONE);
                }
            }
        });




    }
}