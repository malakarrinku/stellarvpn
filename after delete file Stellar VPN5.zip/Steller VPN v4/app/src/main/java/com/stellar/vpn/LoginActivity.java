package com.stellar.vpn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;
import com.stellar.vpn.api.Const;

import org.json.JSONException;
import org.json.JSONObject;

import com.stellar.vpn.utils.Pref;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {
    private TextView sign_up,forgot_pass;
    Pref prefs;
    CardView login_to_mainpage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        prefs = new Pref(this);

        /*this is for windows popup*/
      //  showpopup();

        sign_up=findViewById(R.id.sign_up);
        login_to_mainpage=findViewById(R.id.login_to_mainpage);
        forgot_pass=findViewById(R.id.forgot_pass);

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,SignupActivity.class);
                startActivity(intent);
                finish();
            }
        });


        login_to_mainpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Assuming you have the email and password fields initialized and getting their texts
                String email = ((TextInputEditText) findViewById(R.id.login_email)).getText().toString();
                String password = ((TextInputEditText) findViewById(R.id.login_password)).getText().toString();

                if (!email.isEmpty() && !password.isEmpty()) {
//                    if (isValidEmail(email)) {
//                        performLogin(email, password);
//                    } else {
//                        Toast.makeText(LoginActivity.this, "Please enter a valid email", Toast.LENGTH_SHORT).show();
//                    }

                    performLogin(email, password); // Removed validation
                } else {
                    Toast.makeText(LoginActivity.this, "Please fill in the credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });

        forgot_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,ForgotPasswordActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        return;
    }

    private boolean isValidEmail(String email) {
        // Use a regex pattern to check if the email format is valid
        String regex = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

private void performLogin(String email, String password) {

    String url = Const.login_api + "?username=" + email + "&password=" + password;

    ProgressDialog progressDialog = new ProgressDialog(this);
    progressDialog.setMessage("Logging in...");
    progressDialog.setCancelable(false);
    progressDialog.show();

    StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
            new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    progressDialog.dismiss();
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        int responseCode = jsonResponse.getInt("response_code");

                        if (responseCode == 200) {
                            prefs.saveCredentials(email,password);
                            Toast.makeText(LoginActivity.this, "Login success", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(LoginActivity.this, "Incorrect credentials", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(LoginActivity.this, "Error parsing response: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            },
            new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, "Error occurred: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

    // Add the request to the RequestQueue.
    Volley.newRequestQueue(this).add(stringRequest);
}


}