package com.stellar.vpn.utils;

import static android.content.Context.MODE_PRIVATE;
import static com.stellar.vpn.utils.Utils.getImgURL;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.util.Log;

import com.stellar.vpn.R;
import com.stellar.vpn.model.Server;

/***
 * Created By Saurya (ChikuAI Official)
 * Our Website = https://developer.chikuaicode.com/
 * Date : Fri,August,05 / 09 / 2022
 * Updated : Fri,September,23 /09 /2022
 */


public class Pref {

    static final String APP_PREFS_NAME = "VPNPreference";

    SharedPreferences mPreference;
    SharedPreferences.Editor mPrefEditor;
    Context context;

    static final String SERVER_COUNTRY = "server_country";
    static final String SERVER_FLAG = "server_flag";
    static final String SERVER_OVPN = "server_ovpn";
    static final String SERVER_OVPN_USER = "server_ovpn_user";
    static final String SERVER_OVPN_PASSWORD = "server_ovpn_password";

    private static final String PREFERENCES_NAME = "user_login";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PASSWORD = "password";

    static final String SERVER_POSITION = "server_position";

    static final String VPN_TIME = "connection_start_time";
    static final String AUTO_CONNECT = "auto_connect";
    static final String SWITCH_BLOCK = "switch_block";


    public Pref(Context context) {
        this.mPreference = context.getSharedPreferences(APP_PREFS_NAME, MODE_PRIVATE);
        this.mPrefEditor = mPreference.edit();
        this.context = context;
    }

    public void saveServer(Server server) {
        mPrefEditor.putString(SERVER_COUNTRY, server.getCountry());
        mPrefEditor.putString(SERVER_FLAG, server.getFlagUrl());
        mPrefEditor.putString(SERVER_OVPN, server.getOvpn());
        mPrefEditor.putString(SERVER_OVPN_USER, server.getOvpnUserName());
        mPrefEditor.putString(SERVER_OVPN_PASSWORD, server.getOvpnUserPassword());
        mPrefEditor.commit();
        Log.d("Save server", server.getCountry());
    }

    public Server getServer() {
        Log.d("Get server", mPreference.getString(SERVER_COUNTRY,"Default"));
        return new Server(
                mPreference.getString(SERVER_COUNTRY, "None"),
                mPreference.getString(SERVER_FLAG, getImgURL(R.drawable.ic_japan)),
                mPreference.getString(SERVER_OVPN, "em"),
                mPreference.getString(SERVER_OVPN_USER, "vpn"),
                mPreference.getString(SERVER_OVPN_PASSWORD, "vpn")
        );
    }

    public void saveServerPosition(int position){
        Log.d("Saved Position", "pos: "+ position);
        mPrefEditor.putInt(SERVER_POSITION, position);
        mPrefEditor.commit();
    }

    public int getServerPosition() {
        // Set a default value (-1) indicating no server is selected
        Log.d("Get server position", "pos: " + mPreference.getInt(SERVER_POSITION, 0));
        return mPreference.getInt(SERVER_POSITION, 0);
    }

    public void saveVpnStartTime(){
//        mPrefEditor.putLong(VPN_TIME, System.currentTimeMillis());
        mPrefEditor.putLong(VPN_TIME, SystemClock.elapsedRealtime());
        mPrefEditor.commit();
    }

    public long getVpnStartTime(){
        return mPreference.getLong(VPN_TIME, 0);
    }

    public void resetVpnStartTime(){
        mPrefEditor.remove("connection_start_time");
        mPrefEditor.commit();
    }


    public void saveCredentials(String email, String password) {
        mPrefEditor.putString(KEY_EMAIL, email);
        mPrefEditor.putString(KEY_PASSWORD, password);
        mPrefEditor.apply();
    }

    public String[] getCredentials() {
        String email = mPreference.getString(KEY_EMAIL, null);
        String password = mPreference.getString(KEY_PASSWORD, null);
        return new String[]{email, password};
    }
    public void deleteCredentials() {
        mPrefEditor.remove(KEY_EMAIL);
        mPrefEditor.remove(KEY_PASSWORD);
        mPrefEditor.apply();
    }

    public void saveAutoConnect(boolean auto){
        mPrefEditor.putBoolean(AUTO_CONNECT, auto);
        mPrefEditor.commit();
    }

    public boolean getAutoConnect(){
        return mPreference.getBoolean(AUTO_CONNECT, true);
    }

    public void saveSwitchBlock(boolean sw){
        mPrefEditor.putBoolean(SWITCH_BLOCK, sw);
        mPrefEditor.commit();
    }

    public boolean getSwitchBlock(){
        return mPreference.getBoolean(SWITCH_BLOCK, true);
    }

}
