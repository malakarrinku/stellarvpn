package com.stellar.vpn.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class RuntimePermissionUtils {

    private static final int PERMISSION_REQUEST_CODE = 1; // You can choose any integer

    public static void requestNotificationPermission(Activity activity) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.POST_NOTIFICATIONS)) {
                // Show an explanation to the user (this should be more user-friendly in a real app)
                Toast.makeText(activity, "Notification permission is needed to show notifications.", Toast.LENGTH_LONG).show();
            }
            // Request the permission
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.POST_NOTIFICATIONS}, PERMISSION_REQUEST_CODE);
        } else {
            // Permission has already been granted
            // You might want to do something if the permission is already available
        }
    }

    public static void handleRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults, Context context) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                Toast.makeText(context, "Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                // Permission was denied
                Toast.makeText(context, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
        // Handle other permissions if there are any
    }
}
