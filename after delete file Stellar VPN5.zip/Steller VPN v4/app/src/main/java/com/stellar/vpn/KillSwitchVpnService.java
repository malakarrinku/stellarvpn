package com.stellar.vpn;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;

public class KillSwitchVpnService extends VpnService {
    private static final String CHANNEL_ID = "Kill Switch";
    private static final int SERVICE_ID = 1010;


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        // Using Builder to configure the VPN
        Builder builder = new Builder();

        // Set the VPN's address, routes, etc.
        builder.addAddress("192.168.0.1", 24);
        builder.addRoute("0.0.0.0", 0);

        try {
            // Start the VPN connection
            ParcelFileDescriptor vpnInterface = builder.establish();
            if (vpnInterface == null) {
                Log.e("Kill Switch", "VPN Builder failed to establish the interface.");
                // Handle the error
            }
            // Rest of your code to handle the established VPN
            permanentNotification("Kill Switch is enabled");
        } catch (Exception e) {
            Log.e("Kill Switch", "Exception in starting VPN Service", e);
            // Handle the exception
        }

        // ... Use the vpnInterface to monitor the VPN connection, handle traffic, etc.

        return START_STICKY;
    }

    @Override
    public void onRevoke() {
        super.onRevoke();
        Log.i("Kill Switch", "Kill switch permission revoked");
    }

    @Override
    public void onDestroy() {
        Log.d("Kill Switch", "Kill Switch Destroyed");
        // Clean up any resources and stop the service
        stopForeground(true);
        super.onDestroy();
    }


    // You might also want to override other methods, such as onRevoke(),
    // which is called when the system revokes the permissions of this service.

    public void permanentNotification(String str) {
        Notification notification;

        // Create an explicit intent for an Activity in your app
        Intent intent = new Intent(this, SettingActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Create the notification channel for API 26+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "VPN Service",
                    NotificationManager.IMPORTANCE_LOW // Set the importance to low to avoid sound
            );
            channel.setDescription("Notifications for VPN service");
            // No sound, vibration, etc.
            channel.setSound(null, null);
            channel.setVibrationPattern(new long[]{0});
            channel.enableVibration(false);
            // Register the channel with the system
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);

            notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Steller VPN")
                    .setContentText(str)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentIntent(pendingIntent) // Add this line to set the PendingIntent
                    .setOngoing(true) // This makes the notification permanent
                    .build();
        } else {
            // For devices running Android 7 (Nougat) and below
            notification = new Notification.Builder(this)
                    .setContentTitle("Steller VPN")
                    .setContentText(str)
                    .setSmallIcon(R.drawable.ic_notification)
                    .setContentIntent(pendingIntent) // Add this line to set the PendingIntent
                    .setOngoing(true)
                    .setPriority(Notification.PRIORITY_LOW) // Set priority to low for silent notification
                    .build();
        }

        startForeground(SERVICE_ID, notification);
    }



}

