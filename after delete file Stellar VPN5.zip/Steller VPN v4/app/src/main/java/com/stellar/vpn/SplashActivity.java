package com.stellar.vpn;

import static com.stellar.vpn.utils.Utils.getImgURL;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.billingclient.api.BillingClient;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.stellar.vpn.api.Const;
import com.stellar.vpn.model.Server;
import com.stellar.vpn.utils.Pref;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


/***
 * Created By Saurya (ChikuAI Official)
 * Our Website = https://developer.chikuaicode.com/
 * Date : Fri,August,05 / 09 / 2022
 * Updated : Fri,September,23 /09 /2022
 */


public class SplashActivity extends AppCompatActivity {

    Pref pref;
    SharedPreferences sharedPref;
    boolean hasAgreedToTOS;

    BillingClient billingClient;
    private boolean hardCodedPassword = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        pref = new Pref(SplashActivity.this);
        // Get the SharedPreferences
        sharedPref = getSharedPreferences("appPreferences", MODE_PRIVATE);

        // Check the value of tos_agreed. If it's not set, it will default to false.
        hasAgreedToTOS = sharedPref.getBoolean("tos_agreed", false);

        getAll();


    }




//    public void getAll() {
//
//        StringRequest request = new StringRequest(Const.api + "?pkg=" + getPackageName(), response -> {
//
//            try {
//                JSONArray jsonArray = new JSONArray(response);
//
//                for (int i = 0; i < jsonArray.length(); i++) {
//                    JSONObject object = (JSONObject) jsonArray.get(0);
//
//
//                    AdsHelper.admob_id = object.getString("admob_id").trim();
//                    AdsHelper.admob_banner = object.getString("admob_banner").trim();
//                    AdsHelper.admob_interstitial = object.getString("admob_interstitial").trim();
//                    AdsHelper.admob_native = object.getString("admob_native").trim();
//                    AdsHelper.facebook_id = object.getString("facebook_id").trim();
//                    AdsHelper.facebook_banner = object.getString("facebook_banner").trim();
//                    AdsHelper.facebook_interstitial = object.getString("facebook_interstitial").trim();
//                    AdsHelper.facebook_native = object.getString("facebook_native").trim();
//                    AdsHelper.banner_type = object.getString("banner_type").trim();
//                    AdsHelper.interstitial_type = object.getString("interstitial_type").trim();
//                    AdsHelper.native_type = object.getString("native_type").trim();
//                    AdsHelper.isAds = object.getInt("ads_status") == 1;
//
//
//                    Const.SERVERS = object.getString("servers");
//                    if (pref.getServer().getOvpn().length() < 5) {
//                        setSingleServer();
//                    }
//                    startActivity(new Intent(SplashActivity.this, secondscreen.class));
//                    finish();
//
//                }
//                try {
//                    ApplicationInfo applicationInfo = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
//                    applicationInfo.metaData.putString("com.google.android.gms.ads.APPLICATION_ID", AdsHelper.admob_id);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//                try {
//                    ApplicationInfo applicationInfo = getPackageManager().getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
//                    applicationInfo.metaData.putString("com.facebook.sdk.ApplicationId", AdsHelper.facebook_id);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//
//            } catch (Exception e) {
//                Toast.makeText(this, "Something went wrong..", Toast.LENGTH_SHORT).show();
//                Toast.makeText(SplashActivity.this, "Error " + e.toString(), Toast.LENGTH_SHORT).show();
//            }
//        }, error -> {
//            Log.d("rssssssssss", "getAll: " + error.toString());
//            Toast.makeText(this, "Something went wrong..", Toast.LENGTH_SHORT).show();
//            startActivity(new Intent(SplashActivity.this, MainActivity.class));
//            finish();
//        });
//
//        RequestQueue queue = Volley.newRequestQueue(SplashActivity.this);
//        queue.add(request);
//
//    }
//
//    private void setSingleServer() {
//        try {
//            JSONArray jsonArray = new JSONArray(Const.SERVERS);
//            JSONObject object = (JSONObject) jsonArray.get(0);
//
//            Server server = new Server(object.getString("name"), Utils.imgUrl("flag/", object.getString("flagURL")), object.getString("configFile"), object.getString("username"), object.getString("password"));
//
//            pref.saveServer(server);
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//    }


public void getAll() {
    // Get the passwords array
    String[] passwords = getResources().getStringArray(R.array.passwords);

    StringRequest request = new StringRequest(Const.api + "?pkg=" + getPackageName(), response -> {
        try {
            JSONArray jsonArray = new JSONArray(response);

            if(jsonArray.length() > 0) {
                JSONObject object = jsonArray.getJSONObject(0);

                String countryName = object.getString("alpha-2");
//                int flagResId = getResources().getIdentifier("flag_" + countryName.toLowerCase(), "drawable", getPackageName());
//
//                String flagURL = getImgURL(flagResId); //"flag_" + countryName.toLowerCase(); // Assuming drawable names are in the format "flag_us", "flag_uk", etc.

                //New flag url

//                int flagResId = getResources().getIdentifier("flags/png/" + countryName.toUpperCase(), "drawable", getPackageName());
//
//                String flagURL = getImgURL(flagResId);
                // Convert the country name to uppercase as the filenames are in uppercase
//                String flagName = countryName.toUpperCase();
//
//                // Create the path for the flag asset
//                String flagURL = "file:///android_asset/flags/" + flagName + ".png";


//                Log.i("flag url", flagURL);
                String flagName = "flag_" + countryName.toLowerCase().replace("-", "_");
                int flagResId = getResources().getIdentifier(flagName, "raw", getPackageName());
                String flagURL = getImgURL(flagResId);

//                    String configString = object.getJSONArray("certificate").getString(0);
                // Extracting the certificate
                JSONArray certArray = object.getJSONArray("certificate");
                StringBuilder certBuilder = new StringBuilder();
                for (int j = 0; j < certArray.length(); j++) {
                    String currentLine = certArray.getString(j);
                    if (!currentLine.startsWith("data-ciphers")) {
                        certBuilder.append(currentLine).append(""); // Adding a newline after each line
                    }
                }
                String configString = certBuilder.toString();

                JSONObject authObject = object.getJSONObject("auth");
                String username = authObject.getString("username");
                String password = authObject.getString("password");
//                password = "215586270";

                if (hardCodedPassword){

                    password = passwords[0];

                }

                // Log the details
                Log.d("SERVER_DETAILS", "Country: " + countryName + ", Username: " + username + ", Password: " + password + ", Config: " + configString);

                Server server = new Server(countryName, flagURL, configString, username, password);
                if (pref.getServer().getCountry() == "None") {
                    pref.saveServer(server);
                }

                attemptAutoLogin();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong..", Toast.LENGTH_SHORT).show();
            Log.e("ERROR", e.toString());
        }
    }, error -> {
        Log.e("REQUEST_ERROR", "getAll: " + error.toString());
        Toast.makeText(this, "Something went wrong..", Toast.LENGTH_SHORT).show();

        attemptAutoLogin();
    });

    RequestQueue queue = Volley.newRequestQueue(SplashActivity.this);
    queue.add(request);
}
    private String loadAssetContentAsString(String fileName) throws IOException {
        try (InputStream is = getAssets().open(fileName);
             InputStreamReader isr = new InputStreamReader(is);
             BufferedReader bufferedReader = new BufferedReader(isr)) {

            StringBuilder content = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                content.append(line).append("\n");
            }
            return content.toString();
        }
    }

    private void attemptAutoLogin() {
        Pref prefs = new Pref(SplashActivity.this);
        String[] credentials = prefs.getCredentials();
        String email = credentials[0];
        String password = credentials[1];

        if (email != null && password != null) {
            Log.d("Steller VPN", "credentials found, trying to login...");
            performLogin(email, password);
        } else {
            Log.d("Steller VPN", "No credentials found");
            navigateToLoginOrMain(false);  // false indicates login failed or no credentials.
        }
    }

    private void performLogin(String email, String password) {
        String url = Const.login_api + "?username=" + email + "&password=" + password;
        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Logging in...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    progressDialog.dismiss();
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        int responseCode = jsonResponse.getInt("response_code");

                        Log.d("Steller VPN", "Response Code: "+responseCode);

                        if (responseCode == 200) {
                            navigateToLoginOrMain(true);  // true indicates login success.
                        } else {
                            navigateToLoginOrMain(false);  // false indicates login failed.
                        }
                    } catch (JSONException e) {
                        Toast.makeText(SplashActivity.this, "Error parsing response: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        navigateToLoginOrMain(false);  // false indicates login failed.
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(SplashActivity.this, "Error occurred: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    navigateToLoginOrMain(false);  // false indicates login failed.
                });

        // Add the request to the RequestQueue.
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void navigateToLoginOrMain(boolean loginSuccess) {
        if (loginSuccess) {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
        } else {
            if (hasAgreedToTOS) {
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            } else {
                startActivity(new Intent(SplashActivity.this, secondscreen.class));
            }
        }
        finish();
    }



    @Override
    public void onBackPressed() {
        return;
    }
}
